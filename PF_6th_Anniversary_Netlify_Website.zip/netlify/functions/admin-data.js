import{readData,json,isAdmin}from"./_store.js";
export default async e=>{if(!isAdmin(e))return json(401,{error:"Unauthorized"});const d=await readData();return json(200,{claims:d.claims,winners:d.winners})};
