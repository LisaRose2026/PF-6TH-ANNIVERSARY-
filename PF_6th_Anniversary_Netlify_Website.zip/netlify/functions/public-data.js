import{readData,json}from"./_store.js";
export default async()=>{const d=await readData();return json(200,{winners:d.winners.map(w=>({name:w.name,status:w.status||"Pending"}))})};
