import {getStore} from "@netlify/blobs";
export const store=getStore("pf-anniversary-claims");
export async function readData(){return await store.get("data",{type:"json"})||{claims:[],winners:[]}}
export async function writeData(d){await store.setJSON("data",d)}
export function isAdmin(e){const expected=process.env.ADMIN_PASSWORD;const got=e.headers["x-admin-password"]||e.headers["X-Admin-Password"];return Boolean(expected&&got&&got===expected)}
export function json(statusCode,body){return{statusCode,headers:{"Content-Type":"application/json","Cache-Control":"no-store"},body:JSON.stringify(body)}}
