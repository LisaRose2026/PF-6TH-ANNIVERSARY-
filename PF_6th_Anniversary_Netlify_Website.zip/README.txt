PF 6TH ANNIVERSARY CLAIM PORTAL — NETLIFY DEPLOYMENT

Included:
- Netflix-inspired dark/red responsive website
- Sponsor contribution display: LisaRose 135 Pips + 10k Coins; Anonymous 1 150 Pips; Anonymous 2 250 Pips; total 535 Pips + 10k Coins
- Private claim submission form
- Password-protected admin inbox (only admin can read claim details)
- Admin can add/edit public winner names and update statuses
- Public winner list shows names and status only, never private claim messages

DEPLOY:
1. Extract this ZIP.
2. Create/sign in to a Netlify account.
3. Choose Add new site > Import an existing project and connect a Git repository containing these files. Alternatively drag-and-drop deploy the folder for a static preview, but serverless functions and persistent storage require a proper Netlify project deployment.
4. In Netlify: Site configuration > Environment variables, add:
   ADMIN_PASSWORD = choose-a-long-unique-password
5. Trigger a new deploy after adding the environment variable.
6. Open the site and click ADMIN to sign in.

IMPORTANT:
- Do not share the ADMIN_PASSWORD with winners.
- Netlify Blobs stores claims persistently after deployment. The first deployment may require Netlify to provision the Blobs store automatically.
- This is a working starter implementation, not a substitute for security review. Use a strong unique password, enable Netlify account security, and test admin access before publishing the link.
- The winner list starts empty because no winner usernames were provided. Add each winner through ADMIN > ADD WINNER.
- Sponsor balances are displayed as contributions; this site does not automatically allocate or deduct prizes from sponsor balances.
